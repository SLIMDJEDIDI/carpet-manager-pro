import prisma from "@/lib/prisma";
import { Factory, Printer, PlusCircle, CheckCircle2 } from "lucide-react";
import { revalidatePath } from "next/cache";
import ExportProductionList from "@/components/ExportProductionList";

export default async function ProductionPage() {
  const pendingOrders = await prisma.order.findMany({
    where: { status: "PENDING" },
    include: { brand: true, design: true },
  });

  const productionLists = await prisma.productionList.findMany({
    include: { 
      orders: {
        include: { brand: true, design: true }
      },
      _count: { select: { orders: true } } 
    },
    orderBy: { createdAt: "desc" },
  });

  async function createBatch() {
    "use server";
    
    const orders = await prisma.order.findMany({ 
      where: { status: "PENDING" } 
    });
    
    if (orders.length > 0) {
      const batchName = `Production List ${new Date().toLocaleDateString()}`;
      
      await prisma.productionList.create({
        data: {
          batchName,
          orders: {
            connect: orders.map(o => ({ id: o.id })),
          },
        },
      });

      await prisma.order.updateMany({
        where: { id: { in: orders.map(o => o.id) } },
        data: { status: "IN_PRODUCTION" },
      });

      revalidatePath("/production");
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 border-l-4 border-amber-500 pl-4">Production Control</h1>
        <p className="text-slate-500 text-sm mt-1">Manage orders sent to the factory and generate production lists.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Pending Orders to Batch */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold flex items-center gap-2 text-slate-700">
              <PlusCircle className="w-5 h-5 text-amber-500" />
              Orders Waiting for Factory ({pendingOrders.length})
            </h3>
            {pendingOrders.length > 0 && (
              <form action={createBatch}>
                <button type="submit" className="bg-amber-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-amber-700 transition-all shadow-lg shadow-amber-100 flex items-center gap-2">
                  <Printer className="w-4 h-4" />
                  Create Production List
                </button>
              </form>
            )}
          </div>
          
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm divide-y divide-slate-50 overflow-hidden">
            {pendingOrders.map(order => (
              <div key={order.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-slate-100 rounded-xl border border-slate-200 flex-shrink-0 overflow-hidden">
                    {order.design.imageUrl && <img src={order.design.imageUrl} className="w-full h-full object-cover" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 uppercase">{order.design.code}</span>
                      <p className="font-bold text-slate-900">{order.design.name}</p>
                    </div>
                    <p className="text-sm text-slate-500 font-medium">{order.size} • <span className="text-emerald-600">{order.brand.name}</span></p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-slate-900">{order.customerName}</p>
                  <p className="text-[10px] text-slate-400 font-medium">ORDERED {new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
            ))}
            {pendingOrders.length === 0 && (
              <div className="p-16 text-center text-slate-400 flex flex-col items-center gap-3">
                <CheckCircle2 className="w-12 h-12 opacity-10 text-emerald-500" />
                <p className="font-medium">All orders are currently in production!</p>
              </div>
            )}
          </div>
        </div>

        {/* Previous Production Lists */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold flex items-center gap-2 text-slate-700">
            <Factory className="w-5 h-5 text-slate-400" />
            Active Batches
          </h3>
          <div className="space-y-4">
            {productionLists.map(list => (
              <div key={list.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4 hover:border-amber-200 transition-colors group">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-amber-600 bg-amber-50 px-2 py-1 rounded uppercase">Batch #{list.id.slice(-4)}</span>
                  <span className="text-[10px] font-bold text-slate-400">{new Date(list.createdAt).toLocaleDateString()}</span>
                </div>
                <h4 className="font-black text-slate-900 leading-tight">{list.batchName}</h4>
                <div className="flex flex-wrap items-center justify-between gap-3 text-sm">
                  <span className="text-slate-500 font-bold">{list._count.orders} CARPETS</span>
                  <div className="flex gap-2">
                    <ExportProductionList orders={list.orders} batchName={list.batchName} />
                    <button className="text-amber-600 font-black flex items-center gap-1.5 hover:bg-amber-50 px-3 py-1.5 rounded-xl transition-colors text-xs uppercase tracking-widest border border-amber-100">
                      <Printer className="w-4 h-4" />
                      PRINT
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {productionLists.length === 0 && (
              <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl p-8 text-center text-slate-400">
                <p className="text-sm font-medium">No production batches yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

