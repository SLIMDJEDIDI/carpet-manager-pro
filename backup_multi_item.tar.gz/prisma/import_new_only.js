const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');
const prisma = new PrismaClient();

async function main() {
  const dataPath = path.join(__dirname, '..', 'new_orders_2026.json');
  const rawData = fs.readFileSync(dataPath, 'utf8');
  const orders = JSON.parse(rawData);

  console.log(`Starting clean import of ${orders.length} orders from ORDER TAKING...`);

  // 1. Pre-fetch brands
  const brands = await prisma.brand.findMany();
  const brandMap = {};
  brands.forEach(b => {
    brandMap[b.name] = b.id;
  });

  // 2. Ensure a "DEFAULT" design exists
  const defaultDesign = await prisma.design.upsert({
    where: { code: 'DEFAULT' },
    update: {},
    create: { 
      code: 'DEFAULT', 
      name: 'Standard Design',
      imageUrl: null
    },
  });

  let importedCount = 0;
  let skippedCount = 0;

  for (const o of orders) {
    try {
      // Parse date DD/MM/YYYY
      const dateParts = o.orderDate.split('/');
      let orderDate = new Date();
      if (dateParts.length === 3) {
        orderDate = new Date(parseInt(dateParts[2]), parseInt(dateParts[1]) - 1, parseInt(dateParts[0]));
      }

      const brandId = brandMap[o.brand];
      if (!brandId) {
        console.warn(`Skipping order due to unknown brand: ${o.brand}`);
        skippedCount++;
        continue;
      }

      await prisma.order.create({
        data: {
          customerName: o.customerName || "Unknown Customer",
          customerPhone: o.customerPhone || "00000000",
          customerAddress: o.customerAddress || "No Address Provided",
          size: o.size || "Standard",
          brandId: brandId,
          designId: defaultDesign.id,
          status: o.status || "PENDING",
          createdAt: orderDate,
        }
      });
      importedCount++;
    } catch (err) {
      console.error(`Failed to import order: ${JSON.stringify(o)}`, err);
      skippedCount++;
    }
  }

  console.log(`Import Complete!`);
  console.log(`- Imported: ${importedCount}`);
  console.log(`- Skipped/Errors: ${skippedCount}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
