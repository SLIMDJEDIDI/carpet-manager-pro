const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');
const prisma = new PrismaClient();

async function main() {
  const dataPath = path.join(__dirname, '..', 'fixed_shipping_2026.json');
  const rawData = fs.readFileSync(dataPath, 'utf8');
  const orders = JSON.parse(rawData);

  console.log(`Starting import of ${orders.length} shipped orders from SHIPPING ORDERS...`);

  // 1. Pre-fetch brands
  const brands = await prisma.brand.findMany();
  const brandMap = {};
  brands.forEach(b => {
    brandMap[b.name] = b.id;
  });

  // 2. Ensure a "DEFAULT" design exists
  const defaultDesign = await prisma.design.upsert({
    where: { code: 'DEFAULT' },
    update: {},
    create: { 
      code: 'DEFAULT', 
      name: 'Standard Design',
      imageUrl: null
    },
  });

  let importedCount = 0;
  let skippedCount = 0;

  for (const o of orders) {
    try {
      // Parse date DD/MM/YYYY
      const dateParts = o.Date ? o.Date.split('/') : [];
      let orderDate = new Date();
      if (dateParts.length === 3) {
        orderDate = new Date(parseInt(dateParts[2]), parseInt(dateParts[1]) - 1, parseInt(dateParts[0]));
      }

      const brandId = brandMap[o.Brand];
      if (!brandId) {
        // Fallback to ZARBITI if unknown, as requested to move every order to convenient brand
        // console.warn(`Unknown brand ${o.Brand}, using ZARBITI`);
      }

      // Cleanup Phone/Name/Address if mixed
      let name = o.Name || "";
      let phone = o.Phone || "";
      let address = o.Address || "";

      // If name is empty but phone has content, it might be mixed
      if (name === "" && phone.includes("\n")) {
        const lines = phone.split("\n");
        name = lines[0].trim();
        phone = lines[lines.length - 1].replace(/\D/g, "");
        if (lines.length > 2) address = lines.slice(1, -1).join(", ").trim();
      }

      await prisma.order.create({
        data: {
          customerName: name || "Unknown Customer",
          customerPhone: phone.replace(/\D/g, "") || "00000000",
          customerAddress: address || "No Address Provided",
          size: o.Dimension || "Standard",
          brandId: brandId || brandMap['ZARBITI'],
          designId: defaultDesign.id,
          status: "SHIPPED",
          createdAt: orderDate,
        }
      });
      importedCount++;
    } catch (err) {
      // console.error(`Failed to import order: ${JSON.stringify(o)}`, err);
      skippedCount++;
    }
  }

  console.log(`Import Complete!`);
  console.log(`- Imported: ${importedCount}`);
  console.log(`- Skipped/Errors: ${skippedCount}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
