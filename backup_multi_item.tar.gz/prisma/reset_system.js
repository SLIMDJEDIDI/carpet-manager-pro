const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log('Cleaning all orders and non-core brands...');
  
  // Delete all orders
  const deleteOrders = await prisma.order.deleteMany({});
  console.log(`Deleted ${deleteOrders.count} orders.`);

  // Delete all production lists
  const deleteLists = await prisma.productionList.deleteMany({});
  console.log(`Deleted ${deleteLists.count} production lists.`);

  // Reset brands to exactly the 3 needed
  await prisma.brand.deleteMany({});
  const brands = ['ZARBITI', 'BMT', 'TBP'];
  for (const name of brands) {
    await prisma.brand.create({ data: { name } });
  }
  console.log('Brands reset to: ZARBITI, BMT, TBP');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
