import prisma from "@/lib/prisma";
import { Search, Plus, Palette } from "lucide-react";
import Link from "next/link";

export default async function DesignCatalog({
  searchParams,
}: {
  searchParams: { q?: string };
}) {
  const query = searchParams.q || "";
  
  const designs = await prisma.design.findMany({
    where: {
      OR: [
        { name: { contains: query } },
        { code: { contains: query } },
      ],
    },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 border-l-4 border-emerald-500 pl-4">Design Catalog</h1>
          <p className="text-slate-500 text-sm mt-1">Manage your carpet patterns and codes.</p>
        </div>
        <Link 
          href="/designs/new"
          className="bg-emerald-600 text-white px-5 py-2.5 rounded-xl flex items-center gap-2 hover:bg-emerald-700 transition-all font-semibold shadow-md shadow-emerald-100"
        >
          <Plus className="w-4 h-4" />
          Add New Design
        </Link>
      </div>

      <div className="flex gap-4 items-center bg-white p-2 rounded-2xl border border-slate-100 shadow-sm">
        <div className="pl-4">
          <Search className="w-5 h-5 text-slate-400" />
        </div>
        <form className="flex-1">
          <input 
            type="text" 
            name="q"
            placeholder="Search by name or code..." 
            defaultValue={query}
            className="w-full bg-transparent border-none focus:ring-0 text-slate-700 py-3"
          />
        </form>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
        {designs.map((design) => (
          <div key={design.id} className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden group hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
            <div className="aspect-[4/5] bg-slate-50 relative overflow-hidden">
              {design.imageUrl ? (
                <img 
                  src={design.imageUrl} 
                  alt={design.name} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-slate-300 flex-col gap-2">
                  <Palette className="w-8 h-8 opacity-20" />
                  <span className="text-xs">No Photo</span>
                </div>
              )}
              <div className="absolute top-3 left-3">
                <span className="text-[10px] font-black bg-white/90 backdrop-blur px-2 py-1 rounded shadow-sm text-slate-800 uppercase tracking-wider">
                  {design.code}
                </span>
              </div>
            </div>
            <div className="p-4 bg-white">
              <h4 className="font-bold text-slate-900 text-sm truncate">{design.name}</h4>
              <p className="text-[10px] text-slate-400 mt-1 uppercase">Ref: {design.code}</p>
            </div>
          </div>
        ))}
        {designs.length === 0 && (
          <div className="col-span-full py-20 text-center text-gray-500">
            No designs found matching your search.
          </div>
        )}
      </div>
    </div>
  );
}
