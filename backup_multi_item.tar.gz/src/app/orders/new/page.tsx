import prisma from "@/lib/prisma";
import { redirect } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import OrderForm from "@/components/OrderForm";

export default async function NewOrderPage() {
  const brands = await prisma.brand.findMany();
  const designs = await prisma.design.findMany({ 
    orderBy: { code: "asc" } 
  });

  async function createOrder(formData: FormData) {
    "use server";
    
    const customerName = formData.get("customerName") as string;
    const customerPhone = formData.get("customerPhone") as string;
    const customerAddress = formData.get("customerAddress") as string;
    const brandId = formData.get("brandId") as string;
    const designId = formData.get("designId") as string;
    const size = formData.get("size") as string;

    await prisma.order.create({
      data: {
        customerName,
        customerPhone,
        customerAddress,
        brandId,
        designId,
        size,
        status: "PENDING",
      },
    });

    redirect("/orders");
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <Link href="/orders" className="flex items-center gap-2 text-slate-400 hover:text-slate-900 transition-all font-black uppercase text-xs tracking-widest group">
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        Back to Orders
      </Link>

      <div className="border-l-8 border-emerald-500 pl-6">
        <h1 className="text-4xl font-black text-slate-900 tracking-tight uppercase">New Messenger Order</h1>
        <p className="text-slate-500 font-bold">Quickly enter the order from your phone or PC.</p>
      </div>

      <OrderForm brands={brands} designs={designs} action={createOrder} />
    </div>
  );
}
