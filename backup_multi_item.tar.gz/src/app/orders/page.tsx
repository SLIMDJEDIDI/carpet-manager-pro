import prisma from "@/lib/prisma";
import { Plus, Search, Filter } from "lucide-react";
import Link from "next/link";
import { format } from "date-fns";

export default async function OrdersPage() {
  const orders = await prisma.order.findMany({
    include: {
      brand: true,
      design: true,
    },
    orderBy: { createdAt: "desc" },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "PENDING": return "bg-gray-100 text-gray-600";
      case "IN_PRODUCTION": return "bg-amber-100 text-amber-600";
      case "WRAPPED": return "bg-blue-100 text-blue-600";
      case "SHIPPED": return "bg-purple-100 text-purple-600";
      case "DELIVERED": return "bg-green-100 text-green-600";
      default: return "bg-gray-100 text-gray-600";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Orders Management</h1>
          <p className="text-gray-500">Track and manage your carpet orders across all brands.</p>
        </div>
        <Link href="/orders/new" className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-indigo-700 transition-colors">
          <Plus className="w-4 h-4" />
          New Order
        </Link>
      </div>

      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="p-4 text-xs font-bold text-gray-500 uppercase">Order Date</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase">Customer</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase">Brand</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase">Carpet Details</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase">Status</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase">Parcel No.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                  <td className="p-4 text-sm text-gray-600">
                    {format(order.createdAt, "MMM d, yyyy")}
                  </td>
                  <td className="p-4">
                    <p className="font-semibold text-gray-900">{order.customerName}</p>
                    <p className="text-xs text-gray-500">{order.customerPhone}</p>
                  </td>
                  <td className="p-4">
                    <span className="text-sm px-2 py-1 bg-gray-100 rounded text-gray-600">
                      {order.brand.name}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      {order.design.imageUrl && (
                        <img src={order.design.imageUrl} className="w-8 h-8 rounded border border-gray-100" />
                      )}
                      <div>
                        <p className="text-sm font-medium text-gray-900">{order.design.code} - {order.design.name}</p>
                        <p className="text-xs text-gray-500">Size: {order.size}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className={`text-xs font-bold px-2 py-1 rounded-full ${getStatusColor(order.status)}`}>
                      {order.status.replace("_", " ")}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-gray-500 font-mono">
                    {order.parcelNumber || "—"}
                  </td>
                </tr>
              ))}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-gray-500">
                    No orders yet. Click "New Order" to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
