import prisma from "@/lib/prisma";
import Link from "next/link";
import { 
  Users, 
  ShoppingCart, 
  Clock, 
  CheckCircle2 
} from "lucide-react";

export default async function Dashboard() {
  const brandsData = await prisma.brand.findMany({
    include: { _count: { select: { orders: true } } }
  });

  const totalOrdersCount = await prisma.order.count();
  
  const stats = [
    { label: "Total Orders", value: "0", icon: ShoppingCart, color: "text-blue-600", bg: "bg-blue-100", href: "/orders" },
    { label: "Pending Production", value: "0", icon: Clock, color: "text-amber-600", bg: "bg-amber-100", href: "/production" },
    { label: "Produced Today", value: "0", icon: CheckCircle2, color: "text-green-600", bg: "bg-green-100", href: "/shipping" },
    { label: "Total Customers", value: "0", icon: Users, color: "text-purple-600", bg: "bg-purple-100", href: "/orders" },
  ];

  // Fetch real stats
  try {
    const pendingProduction = await prisma.order.count({ where: { status: "PENDING" } });
    const totalCustomers = await prisma.order.groupBy({ by: ['customerPhone'] }).then(res => res.length);
    const producedToday = await prisma.order.count({ 
      where: { 
        status: { in: ["WRAPPED", "SHIPPED"] },
        updatedAt: { gte: new Date(new Date().setHours(0,0,0,0)) }
      } 
    });
    
    stats[0].value = totalOrdersCount.toString();
    stats[1].value = pendingProduction.toString();
    stats[2].value = producedToday.toString();
    stats[3].value = totalCustomers.toString();
  } catch (e) {
    console.error("Failed to fetch stats", e);
  }

  return (
    <div className="space-y-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Enterprise Overview</h1>
          <p className="text-slate-500 font-medium">Real-time stats for ZARBITI, BMT, and TBP.</p>
        </div>
        <div className="bg-white px-4 py-2 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-3">
          <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse"></div>
          <span className="text-sm font-bold text-slate-600 uppercase tracking-wider">System Live</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <Link 
            key={i} 
            href={stat.href}
            className="bg-white p-7 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex items-center gap-5 group"
          >
            <div className={`p-4 rounded-2xl ${stat.bg} group-hover:scale-110 transition-transform`}>
              <stat.icon className={`w-7 h-7 ${stat.color}`} />
            </div>
            <div>
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{stat.label}</p>
              <p className="text-3xl font-black text-slate-900">{stat.value}</p>
            </div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Orders */}
        <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">Recent Activity</h3>
            <Link href="/orders" className="text-xs font-black text-emerald-600 hover:text-emerald-700 uppercase tracking-widest">View All</Link>
          </div>
          <div className="space-y-4 text-sm text-slate-400 text-center py-16 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-100">
             <ShoppingCart className="w-12 h-12 mx-auto mb-4 opacity-10" />
             Track your latest orders and their status in real-time.
          </div>
        </div>

        {/* Brand Performance */}
        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
          <h3 className="text-xl font-black text-slate-900 mb-8 uppercase tracking-tight">Brand Reach</h3>
          <div className="space-y-8">
            {brandsData.map((brand) => {
              const percentage = totalOrdersCount > 0 
                ? Math.round((brand._count.orders / totalOrdersCount) * 100) 
                : 0;
              return (
                <div key={brand.id} className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-black text-slate-700 uppercase">{brand.name}</span>
                    <span className="text-xs font-bold text-slate-400">{percentage}%</span>
                  </div>
                  <div className="w-full h-3 bg-slate-50 rounded-full overflow-hidden border border-slate-100">
                    <div 
                      className="bg-emerald-500 h-full transition-all duration-1000" 
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
