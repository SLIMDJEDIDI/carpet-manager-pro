import prisma from "@/lib/prisma";
import { Factory, Printer, PlusCircle, CheckCircle2 } from "lucide-react";
import { revalidatePath } from "next/cache";
import ExportProductionList from "@/components/ExportProductionList";

export default async function ProductionPage() {
  const brands = await prisma.brand.findMany();
  
  const pendingOrders = await prisma.order.findMany({
    where: { status: "PENDING" },
    include: { brand: true, design: true },
  });

  const productionLists = await prisma.productionList.findMany({
    include: { 
      orders: {
        include: { brand: true, design: true }
      },
      _count: { select: { orders: true } } 
    },
    orderBy: { createdAt: "desc" },
  });

  async function createBatch(formData: FormData) {
    "use server";
    
    const brandId = formData.get("brandId") as string;
    const brandName = formData.get("brandName") as string;
    
    const orders = await prisma.order.findMany({ 
      where: { 
        status: "PENDING",
        brandId: brandId
      } 
    });
    
    if (orders.length > 0) {
      const batchName = `${brandName} - List ${new Date().toLocaleDateString()}`;
      
      await prisma.productionList.create({
        data: {
          batchName,
          orders: {
            connect: orders.map(o => ({ id: o.id })),
          },
        },
      });

      await prisma.order.updateMany({
        where: { id: { in: orders.map(o => o.id) } },
        data: { status: "IN_PRODUCTION" },
      });

      revalidatePath("/production");
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 border-l-4 border-amber-500 pl-4">Production Control</h1>
        <p className="text-slate-500 text-sm mt-1">Manage orders sent to the factory. Lists are created separately for each brand.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Pending Orders Grouped by Brand */}
        <div className="lg:col-span-2 space-y-10">
          {brands.map(brand => {
            const brandPending = pendingOrders.filter(o => o.brandId === brand.id);
            if (brandPending.length === 0) return null;

            return (
              <div key={brand.id} className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-black flex items-center gap-2 text-slate-700 uppercase tracking-tight">
                    <PlusCircle className="w-5 h-5 text-amber-500" />
                    {brand.name} Pending ({brandPending.length})
                  </h3>
                  <form action={createBatch}>
                    <input type="hidden" name="brandId" value={brand.id} />
                    <input type="hidden" name="brandName" value={brand.name} />
                    <button type="submit" className="bg-amber-600 text-white px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-amber-700 transition-all shadow-lg shadow-amber-100 flex items-center gap-2">
                      <Printer className="w-4 h-4" />
                      Create {brand.name} List
                    </button>
                  </form>
                </div>
                
                <div className="bg-white rounded-2xl border border-slate-100 shadow-sm divide-y divide-slate-50 overflow-hidden">
                  {brandPending.map(order => (
                    <div key={order.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-slate-100 rounded-xl border border-slate-200 flex-shrink-0 overflow-hidden">
                          {order.design.imageUrl && <img src={order.design.imageUrl} className="w-full h-full object-cover" />}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-black bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 uppercase">{order.design.code}</span>
                            <p className="font-bold text-slate-900">{order.design.name}</p>
                          </div>
                          <p className="text-sm text-slate-500 font-medium">{order.size}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold text-slate-900">{order.customerName}</p>
                        <p className="text-[10px] text-slate-400 font-medium uppercase">ORDERED {new Date(order.createdAt).toLocaleDateString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {pendingOrders.length === 0 && (
            <div className="p-20 text-center text-slate-400 flex flex-col items-center gap-3 bg-white rounded-[2.5rem] border border-slate-100">
              <CheckCircle2 className="w-16 h-16 opacity-10 text-emerald-500" />
              <p className="font-black uppercase tracking-widest text-xs">All brand orders are currently in production!</p>
            </div>
          )}
        </div>

        {/* Previous Production Lists */}
        <div className="space-y-6">
          <h3 className="text-lg font-black flex items-center gap-2 text-slate-700 uppercase tracking-tight">
            <Factory className="w-5 h-5 text-slate-400" />
            Active Batches
          </h3>
          <div className="space-y-4">
            {productionLists.map(list => (
              <div key={list.id} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4 hover:border-amber-200 transition-colors group">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-amber-600 bg-amber-50 px-2.5 py-1 rounded uppercase tracking-widest flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse"></div>
                    Batch #{list.id.slice(-4)}
                  </span>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{new Date(list.createdAt).toLocaleDateString()}</span>
                </div>
                <h4 className="font-black text-slate-900 leading-tight text-lg">{list.batchName}</h4>
                <div className="flex flex-wrap items-center justify-between gap-3 text-sm">
                  <span className="text-slate-500 font-black text-xs uppercase tracking-widest">{list._count.orders} CARPETS</span>
                  <div className="flex gap-2">
                    <ExportProductionList orders={list.orders} batchName={list.batchName} />
                    <button className="text-amber-600 font-black flex items-center gap-1.5 hover:bg-amber-50 px-3 py-1.5 rounded-xl transition-colors text-xs uppercase tracking-widest border border-amber-100">
                      <Printer className="w-4 h-4" />
                      PRINT
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {productionLists.length === 0 && (
              <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl p-10 text-center text-slate-400">
                <p className="text-xs font-black uppercase tracking-widest">No production batches yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
