import prisma from "@/lib/prisma";
import { Truck, Package, Search, ExternalLink, CheckCircle2, MessageSquare } from "lucide-react";
import PrintLabel from "@/components/PrintLabel";
import { revalidatePath } from "next/cache";

export default async function ShippingPage() {
  const orders = await prisma.order.findMany({
    where: {
      status: { in: ["IN_PRODUCTION", "WRAPPED", "SHIPPED"] }
    },
    include: { brand: true, design: true },
    orderBy: [{ status: "asc" }, { updatedAt: "desc" }],
  });

  async function updateStatus(orderId: string, status: string, parcelNumber?: string) {
    "use server";
    await prisma.order.update({
      where: { id: orderId },
      data: { 
        status: status,
        ...(parcelNumber ? { parcelNumber } : {})
      },
    });
    revalidatePath("/shipping");
  }

  async function shipOrder(formData: FormData) {
    "use server";
    const orderId = formData.get("orderId") as string;
    const parcelNumber = formData.get("parcelNumber") as string;
    
    await prisma.order.update({
      where: { id: orderId },
      data: { status: "SHIPPED", parcelNumber },
    });
    revalidatePath("/shipping");
  }

  async function markAsWrapped(orderId: string) {
    "use server";
    await prisma.order.update({
      where: { id: orderId },
      data: { status: "WRAPPED" },
    });
    revalidatePath("/shipping");
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="border-l-8 border-blue-500 pl-6">
          <h1 className="text-4xl font-black text-slate-900 tracking-tight uppercase">Shipping Desk</h1>
          <p className="text-slate-500 font-bold text-sm mt-1">Ready to wrap and ship your carpets.</p>
        </div>
        <div className="bg-blue-50 px-6 py-3 rounded-2xl border border-blue-100 flex items-center gap-3">
          <Package className="w-5 h-5 text-blue-600" />
          <span className="text-sm font-black text-blue-700 uppercase tracking-widest">
            {orders.filter(o => o.status === "WRAPPED").length} Ready for Shipping
          </span>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="p-6 text-xs font-black text-slate-400 uppercase tracking-widest">Customer</th>
                <th className="p-6 text-xs font-black text-slate-400 uppercase tracking-widest">Specs</th>
                <th className="p-6 text-xs font-black text-slate-400 uppercase tracking-widest">Status</th>
                <th className="p-6 text-xs font-black text-slate-400 uppercase tracking-widest">Parcel Tracking</th>
                <th className="p-6 text-xs font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="p-6">
                    <p className="font-black text-slate-900">{order.customerName}</p>
                    <p className="text-xs font-bold text-slate-400 uppercase mt-0.5">{order.customerPhone}</p>
                    <p className="text-[10px] text-slate-400 line-clamp-1 max-w-[150px] mt-1">{order.customerAddress}</p>
                  </td>
                  <td className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-slate-100 rounded-lg border border-slate-200 flex-shrink-0 overflow-hidden">
                        {order.design.imageUrl && <img src={order.design.imageUrl} className="w-full h-full object-cover" />}
                      </div>
                      <div>
                        <p className="text-xs font-black text-slate-900 uppercase">{order.design.code}</p>
                        <p className="text-[10px] font-bold text-emerald-600 uppercase">{order.size}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-6">
                    <span className={`text-[10px] font-black px-3 py-1.5 rounded-full uppercase tracking-widest ${
                      order.status === "SHIPPED" ? "bg-purple-100 text-purple-600" : 
                      order.status === "WRAPPED" ? "bg-blue-100 text-blue-600" :
                      "bg-amber-100 text-amber-600"
                    }`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="p-6">
                    <form action={shipOrder} className="flex items-center gap-2">
                      <input type="hidden" name="orderId" value={order.id} />
                      <input 
                        type="text" 
                        name="parcelNumber"
                        placeholder="Parcel #" 
                        defaultValue={order.parcelNumber || ""}
                        className="text-xs font-bold border-slate-200 rounded-xl px-3 py-2 focus:ring-blue-500 focus:border-blue-500 w-32 bg-slate-50"
                      />
                      {order.status === "WRAPPED" && (
                        <button type="submit" className="p-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all">
                          <Truck className="w-4 h-4" />
                        </button>
                      )}
                    </form>
                  </td>
                  <td className="p-6 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {order.status === "SHIPPED" && (
                        <a 
                          href={`https://wa.me/${order.customerPhone.replace(/\D/g, "")}?text=Hello ${order.customerName}, your carpet order #${order.id.slice(-6).toUpperCase()} has been shipped! Tracking: ${order.parcelNumber}`}
                          target="_blank"
                          className="bg-emerald-500 text-white p-2 rounded-xl hover:bg-emerald-600 transition-all"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </a>
                      )}
                      {order.status === "IN_PRODUCTION" && (
                        <form action={markAsWrapped.bind(null, order.id)}>
                          <button type="submit" className="text-emerald-600 font-black text-[10px] uppercase border border-emerald-100 px-3 py-1.5 rounded-xl hover:bg-emerald-50 transition-colors">
                            Mark Wrapped
                          </button>
                        </form>
                      )}
                      <PrintLabel order={order as any} />
                    </div>
                  </td>
                </tr>
              ))}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-20 text-center text-slate-400">
                    <Package className="w-16 h-16 mx-auto mb-4 opacity-5" />
                    <p className="font-bold uppercase tracking-widest text-xs">No orders ready for shipping.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
