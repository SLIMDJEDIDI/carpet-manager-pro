"use client";

import { useState, useEffect } from "react";
import { Search, User, MapPin, Phone, Palette, Ruler, ShoppingBag } from "lucide-react";

interface Brand {
  id: string;
  name: string;
}

interface Design {
  id: string;
  name: string;
  code: string;
}

interface OrderFormProps {
  brands: Brand[];
  designs: Design[];
  action: (formData: FormData) => Promise<void>;
}

export default function OrderForm({ brands, designs, action }: OrderFormProps) {
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [hasPending, setHasPending] = useState(false);

  useEffect(() => {
    const timer = setTimeout(async () => {
      if (phone.length >= 8) {
        setIsSearching(true);
        try {
          const res = await fetch(`/api/customers/search?phone=${phone}`);
          const data = await res.json();
          if (data.found) {
            setName(data.name);
            setAddress(data.address);
          }
          setHasPending(data.hasPending);
        } catch (e) {
          console.error("Search failed", e);
        } finally {
          setIsSearching(false);
        }
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [phone]);

  return (
    <form action={action} className="space-y-8 bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-100">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-3">
          <label className="text-sm font-black text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-emerald-500" />
            Selling Brand
          </label>
          <select 
            name="brandId" 
            required 
            className="w-full rounded-2xl border-slate-200 focus:border-emerald-500 focus:ring-emerald-500 h-14 bg-slate-50 font-bold"
          >
            <option value="">Select Brand</option>
            {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </div>
        
        <div className="space-y-3">
          <label className="text-sm font-black text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <Ruler className="w-4 h-4 text-emerald-500" />
            Carpet Size
          </label>
          <input 
            type="text" 
            name="size" 
            required 
            placeholder="e.g. 2x3 or 4x5" 
            className="w-full rounded-2xl border-slate-200 focus:border-emerald-500 focus:ring-emerald-500 h-14 bg-slate-50 font-bold" 
          />
        </div>
      </div>

      <div className="space-y-3">
        <label className="text-sm font-black text-slate-700 uppercase tracking-wider flex items-center gap-2">
          <Palette className="w-4 h-4 text-emerald-500" />
          Carpet Design
        </label>
        <select 
          name="designId" 
          required 
          className="w-full rounded-2xl border-slate-200 focus:border-emerald-500 focus:ring-emerald-500 h-14 bg-slate-50 font-bold"
        >
          <option value="">Select Design Code</option>
          {designs.map(d => <option key={d.id} value={d.id}>{d.code} - {d.name}</option>)}
        </select>
      </div>

      <div className="relative py-4">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-slate-100"></span>
        </div>
        <div className="relative flex justify-center text-xs uppercase font-black text-slate-400 bg-white px-4">
          Customer Data (Auto-fills on Phone)
        </div>
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
          <label className="text-sm font-black text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <Phone className="w-4 h-4 text-emerald-500" />
            Phone Number
          </label>
          <div className="relative">
            <input 
              type="text" 
              name="customerPhone" 
              required 
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full rounded-2xl border-slate-200 focus:border-emerald-500 focus:ring-emerald-500 h-14 bg-slate-50 font-bold pl-12" 
            />
            <div className="absolute left-4 top-1/2 -translate-y-1/2">
              {isSearching ? <div className="w-5 h-5 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin"></div> : <Search className="w-5 h-5 text-slate-400" />}
            </div>
          </div>
          {hasPending && (
            <p className="text-xs font-black text-amber-600 uppercase animate-bounce mt-2">
              ⚠️ Warning: This customer already has a pending order!
            </p>
          )}
        </div>

        <div className="space-y-3">
          <label className="text-sm font-black text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <User className="w-4 h-4 text-emerald-500" />
            Full Name
          </label>
          <input 
            type="text" 
            name="customerName" 
            required 
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full rounded-2xl border-slate-200 focus:border-emerald-500 focus:ring-emerald-500 h-14 bg-slate-50 font-bold" 
          />
        </div>

        <div className="space-y-3">
          <label className="text-sm font-black text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-500" />
            Full Delivery Address
          </label>
          <textarea 
            name="customerAddress" 
            required 
            rows={3} 
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="w-full rounded-2xl border-slate-200 focus:border-emerald-500 focus:ring-emerald-500 bg-slate-50 font-bold p-4" 
          />
        </div>
      </div>

      <div className="pt-6">
        <button 
          type="submit" 
          className="w-full bg-emerald-600 text-white py-5 rounded-[2rem] font-black text-lg hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-100 uppercase tracking-widest"
        >
          Confirm Order
        </button>
      </div>
    </form>
  );
}
