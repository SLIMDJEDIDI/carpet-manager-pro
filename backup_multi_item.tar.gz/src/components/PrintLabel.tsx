"use client";

import { Printer, Tag } from "lucide-react";
import jsPDF from "jspdf";

interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  size: string;
  brand: { name: string };
  design: { code: string; name: string };
}

export default function PrintLabel({ order }: { order: Order }) {
  const generatePDF = () => {
    const doc = new jsPDF({
      orientation: "landscape",
      unit: "mm",
      format: [100, 150], // Standard label size
    });

    // Header - Brand Name
    doc.setFont("helvetica", "bold");
    doc.setFontSize(24);
    doc.setTextColor(5, 150, 105); // emerald-600
    doc.text(order.brand.name.toUpperCase(), 75, 20, { align: "center" });

    // Divider
    doc.setDrawColor(200, 200, 200);
    doc.line(10, 25, 140, 25);

    // Customer Info
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(10);
    doc.text("SHIP TO:", 15, 35);
    
    doc.setFontSize(16);
    doc.text(order.customerName.toUpperCase(), 15, 45);
    
    doc.setFontSize(12);
    const splitAddress = doc.splitTextToSize(order.customerAddress, 120);
    doc.text(splitAddress, 15, 55);
    
    doc.setFont("helvetica", "bold");
    doc.text(`PHONE: ${order.customerPhone}`, 15, 80);

    // Product Details Box
    doc.setFillColor(248, 250, 252); // slate-50
    doc.rect(80, 70, 60, 20, "F");
    
    doc.setFontSize(8);
    doc.setTextColor(100, 100, 100);
    doc.text("CARPET SPECS:", 85, 75);
    
    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);
    doc.text(`${order.design.code} - ${order.size}`, 85, 82);

    // Footer
    doc.setFontSize(8);
    doc.text(`Order ID: #${order.id.slice(-6).toUpperCase()}`, 15, 95);

    doc.save(`Label_${order.customerName.replace(/\s+/g, "_")}.pdf`);
  };

  return (
    <button 
      onClick={generatePDF}
      className="bg-slate-900 text-white px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-slate-800 transition-all flex items-center gap-2 shadow-lg shadow-slate-100"
    >
      <Tag className="w-3 h-3" />
      Label
    </button>
  );
}
